# 一:EMQX简介 #
产品概览
EMQX 是一款大规模可弹性伸缩的云原生分布式物联网 MQTT 消息服务器。

作为全球最具扩展性的 MQTT 消息服务器，EMQX 提供了高效可靠海量物联网设备连接，能够高性能实时移动与处理消息和事件流数据，帮助您快速构建关键业务的物联网平台与应用。

#产品优势
开放源码：基于 Apache 2.0 许可证完全开源，自 2013 年起 200+ 开源版本迭代。
MQTT 5.0：100% 支持 MQTT 5.0 和 3.x 协议标准，更好的伸缩性、安全性和可靠性。
海量连接：单节点支持 500 万 MQTT 设备连接，集群可扩展至 1 亿并发 MQTT 连接。
高性能：单节点支持每秒实时接收、移动、处理与分发数百万条的 MQTT 消息。
低时延：基于 Erlang/OTP 软实时的运行时系统设计，消息分发与投递时延低于 1 毫秒。
高可用：采用 Masterless 的大规模分布式集群架构，实现系统高可用和水平扩展。
#功能概览
以下是 EMQX 不完全功能列表。

#连接
完整支持 MQTT v3.1、v3.1.1 和 v5.0 协议规范
QoS 0、QoS 1、QoS 2 消息支持
持久会话和离线消息支持
保留消息（Retained Message）支持
遗嘱消息（Will Message）支持
共享订阅支持
$SYS/ 系统主题支持
MQTT 支持 4 种传输协议
TCP
TLS
WebSocket
QUIC（实验性）
HTTP 消息发布接口
网关
CoAP
LwM2M
MQTT-SN
Stomp
GB/T 32960（企业版）
JT/T 808（企业版）
更多 MQTT 扩展支持：

延迟发布
代理订阅
主题重写
#安全
基于用户名/密码的身份认证，支持使用内置数据库、Redis、MySQL、PostgreSQL、MongoDB 作为数据源，也支持使用 HTTP Server 提供认证服务
基于 JWT 的身份认证与权限控制，支持 JWKs
MQTT 5.0 增强认证
PSK 身份验证
基于 Client ID、IP 地址，用户名的访问控制，支持使用内置数据库、Redis、MySQL、PostgreSQL、MongoDB 作为数据源，也支持使用 HTTP Server 提供授权服务
客户端黑名单支持
#可伸缩性
多节点集群 (Cluster)
支持手动、dns、etcd、k8s 集群发现方式集群
多服务器节点桥接 (Bridge)
#数据集成
SQL 语法数据集成，实时提取、过滤、丰富和转换 MQTT 消息或内部事件为用户所需格式，并将其发送到外部数据平台
通过 MQTT 与其他 Broker 或物联网平台进行双向数据桥接（如 EMQX Cloud，AWS IoT Core，Azure IoT Hub）
通过 Webhook 与其他应用集成
#可靠性
过载保护
消息速率限制
连接速率限制


----------

# 二: 快速开始 EMQX #
## Docker部署
>     
>     1. Docker环境安装
>       安装yum-utils
>       yum install -y yum-utils device-mapper-persistent-data lvm2
>       为yum源添加docker仓库位置：
>       yum-config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo
>       安装Docker
>       yum install docker-ce
>       启动Docker
>       systemctl start docker
>     
>       Docker-Comose 安装
>     
>       curl -L https://get.daocloud.io/docker/compose/releases/download/1.24.0/docker-compose-`uname -s`-`uname -m` /usr/local/bin/docker-compose
>       chmod +x /usr/local/bin/docker-compose
>       docker-compose --version

EMQX 提供了一个容器镜像，您可以在 Docker Hub (opens new window)上了解该镜像的详细信息。通过容器化部署是快速开始体验 EMQX 的最快方式。
下载镜像
>docker pull emqx/emqx:5.0.4

启动 Docker 容器：
>docker run -d --name emqx -p 1883:1883 -p 8083:8083 -p 8084:8084 -p 8883:8883 -p 18083:18083 emqx/emqx:latest


##在虚拟机或物理机中运行
EMQX 可以直接部署在物理服务器或者虚拟机上。最小仅需 2 核 4G 的机器即可运行 EMQX 程序。可支持 CentOS、Debian、Ubuntu、macOS 等操作系统。

RedHat、CentOS、 RockyLinux、AmazonLinux 系统安装
Ubuntu、Debian 安装
MacOS、Windows、Linux tgz 包安装

启动 EMQX
安装成功后，可通过 systemctl 或 emqx 命令来启动 EMQX。

EMQX 成功启动之后可以通过浏览器打开 http://localhost:18083/ (opens new window)（将 localhost 替换为您实际 IP 地址）以访问 EMQX Dashboard 管理控制台，进行设备连接与相关指标监控管理。

#后台启动 EMQX
> emqx start
    
启动成功后可以使用 emqx ping 命令检测节点运行状态，返回 pong 则表示正常运行：

> emqx ping


    
#systemctl 启动
>sudo systemctl start emqx
 
     
    
检查服务是否正常工作：

>sudo systemctl status emqx
 
     
    
#tgz 安装包启动
切换到 EMQX 解压目录，执行以下命令启动 EMQX：

>./bin/emqx start
 
     
    
开发模式下可以使用 console 命令在控制台启动 EMQX，该模式可以实时查看 EMQX 启动和运行输出日志信息：

>./bin/emqx console

使用 MQTT 客户端快速验证
EMQX 提供了标准的 MQTT 协议支持，启动后即可接入 MQTT 客户端，您可以使用以下客户端工具或客户端库接入 EMQX 进行消息通信以完成某些场景或功能的测试验证。

#Dashboard Websocket 工具
打开 Dashboard，进入 问题分析 -> WebSocket 客户端 页面中可以在浏览器中使用 MQTT over WebSokcet 客户端快速接入 EMQX。

WebSocket 客户端页面为您提供了一个简易但有效的 MQTT 测试工具，它包含了连接、订阅和发布功能，同时还能查看自己发送和接收的消息数据。

#MQTT X 桌面客户端工具
MQTTX 是一款优雅的跨平台 MQTT 5.0 开源桌面客户端工具，支持在 macOS、Linux 和 Windows 上运行。

MQTTX 有诸多特性，提供了简洁的图形界面和操作逻辑，支持 MQTT/MQTT over Websocket 接入以及单/双向 SSL 认证，同时支持 Payload 格式转换、自定义脚本模拟测试数据、 $SYS 系统主题自动订阅查看流量统计等诸多实用功能。

下载与使用可参考 MQTTX 官网 [https://mqttx.app/zh](https://mqttx.app/zh "MQTTX 官网")



----------
# 三: 安装部署 EMQX #
EMQX 目前支持的操作系统:

- EL7 (RedHat 7, CentOS 7)
- EL8 (RedHat 8, RockyLinux 8, AmazonLinux 2022)
- Raspbian 10
- Debian 9
- Debian 10
- Ubuntu 16.04
- Ubuntu 18.04
- Ubuntu 20.04
- macOS 10
- macOS 11
- Windows Server 2019
- 
#通过 Docker 运行 (包含简单的 docker-compose 集群)
#运行单个容器
1. 获取 docker 镜像 

   >  docker pull emqx/emqx:5.0.4

2. 启动容器 
   > docker run -d --name emqx -p 1883:1883 -p 8083:8083 -p 8883:8883 -p 8084:8084 -p 18083:18083 emqx/emqx:5.0.4



## 使用 docker-compose 创建简单的 static 集群 ##

1. 创建 docker-compose.yaml 文件

''

    version: '3'

	services:
	  emqx1:
	    image: emqx/emqx:5.0.4
	    container_name: emqx1
	    environment:
	    - "EMQX_NODE_NAME=emqx@node1.emqx.io"
	    - "EMQX_CLUSTER__DISCOVERY_STRATEGY=static"
	    - "EMQX_CLUSTER__STATIC__SEEDS=[emqx@node1.emqx.io,emqx@node2.emqx.io]"
	    healthcheck:
	      test: ["CMD", "/opt/emqx/bin/emqx_ctl", "status"]
	      interval: 5s
	      timeout: 25s
	      retries: 5
	    networks:
	      emqx-bridge:
	        aliases:
	        - node1.emqx.io
	
	  emqx2:
	    image: emqx/emqx:5.0.4
	    environment:
	    - "EMQX_NODE_NAME=emqx@node2.emqx.io"
	    - "EMQX_CLUSTER__DISCOVERY_STRATEGY=static"
	    - "EMQX_CLUSTER__STATIC__SEEDS=[emqx@node1.emqx.io,emqx@node2.emqx.io]"
	    healthcheck:
	      test: ["CMD", "/opt/emqx/bin/emqx_ctl", "status"]
	      interval: 5s
	      timeout: 25s
	      retries: 5
	    networks:
	      emqx-bridge:
	        aliases:
	        - node2.emqx.io
	
	networks:
	  emqx-bridge:
	    driver: bridge




2  启动 docker-compose 集群

>docker-compose up -d

3. 查看集群 
>$ docker exec -it emqx1 sh -c "emqx_ctl cluster status"
>
Cluster status: #{running_nodes => ['emqx@node1.emqx.io','emqx@node2.emqx.io'],
                  stopped_nodes => []}


**之后就可以通过 ip:18083 访问  EMQX web 资源,默认用户名为   admin  密码为 public**


    执行 docker exec -it emqx sh 可以进入容器内容,查看EMQX 的目录结构

    drwxrwxr-x. 1 emqx emqx      137 Jul 28 05:54 .
	drwxr-xr-x. 1 root root       18 Jul 28 05:54 ..
	drwxrwxr-x. 1 emqx emqx     4096 Jul 28 05:54 bin       存放可执行程序  
	drwxrwxr-x. 7 emqx emqx      115 Oct 28 07:34 data      EMQX 将运行数据存储在 data 目录下，
															请确保 EMQX 具有该目录下所有文件的读写权限。
	 -rw-rw-r--. 1 emqx emqx 61839250 Jul 28 05:54 emqx-5.0.4.tar.gz
	drwxrwxr-x. 1 emqx emqx       17 Jul 28 05:54 erts-12.2.1
	drwxrwxr-x. 1 emqx emqx      130 Jul 28 05:54 etc       配置项,包含默认的用户名和密码
	drwxrwxr-x. 1 emqx emqx     4096 Jul 28 05:54 lib
	drwxrwxr-x. 2 emqx emqx        6 Jul 28 05:54 log
	drwxrwxr-x. 1 emqx emqx        6 Jul 28 05:54 plugins
	drwxrwxr-x. 1 emqx emqx       74 Jul 28 05:54 releases

![](./imgs/emqx_login_web_1.png)

![](./imgs/emqx_login_web_2.png)



### 安装包类型 ###
    
    CentOS8 amd64 / rpm  **这种方便测试,但是我发现,缺少很多包, tar.gz 包适用于测试和热更，如果不知道如何手动安装所有可能的运行时依赖，请勿在生产环境中使用。不容易正确运行,所以还是采用Docker容器运行吧**
    
    1.下载 emqx-5.0.9-el8-amd64.rpmSHA256
    
    > wget https://www.emqx.com/zh/downloads/broker/5.0.9/emqx-5.0.9-el8-amd64.rpm
    
    2.安装 EMQX
     
     > sudo yum install emqx-5.0.9-el8-amd64.rpm
    
    3.启动 EMQX
     > sudo systemctl start emqx




----------
2022/10/28 15:38:51 

# **管理接口** #

# 命令行 #

## 启动脚本 ##

    $ emqx help
	Usage: emqx COMMAND [help]
	
	Commonly used COMMANDs:
	  start:      Start EMQX in daemon mode
	  console:    Start EMQX in an interactive Erlang or Elixir shell
	  foreground: Start EMQX in foreground mode without an interactive shell
	  stop:       Stop the running EMQX node
	  ctl:        Administration commands, execute 'emqx ctl help' for more details
	
	More:
	  Shell attach:  remote_console | attach
	  Up/Down-grade: upgrade | downgrade | install | uninstall
	  Install info:  ertspath | root_dir | versions | root_dir
	  Runtime info:  pid | ping | versions
	  Advanced:      console_clean | escript | rpc | rpcterms | eval | eval-erl
	
	Execute 'emqx COMMAND help' for more information



    Usage: emqx_ctl
    --------------------------------------------------------------------------------------------------------------
    observer status   # Start observer in the current console
    observer bin_leak # Force all processes to perform garbage collection and prints the top-100 processes that freed the biggest amount of binaries, potentially highlighting leaks.
    observer load Mod # Ensure a module is loaded in all EMQX nodes in the cluster
    --------------------------------------------------------------------------------------------------------------
    cluster_call status   # status
    cluster_call skip [node]  # increase one commit on specific node
    cluster_call tnxid <TnxId   # get detailed about TnxId
    cluster_call fast_forward [node] [tnx_id] # fast forwards to tnx_id
    --------------------------------------------------------------------------------------------------------------
    admins add <Username<Password<Description# Add dashboard user
    admins passwd <Username<Password   # Reset dashboard user password
    admins del <Username # Delete dashboard user
    --------------------------------------------------------------------------------------------------------------
    retainer info  # Show the count of retained messages
    retainer topics# Show all topics of retained messages
    retainer clean # Clean all retained messages
    retainer clean <Topic# Clean retained messages by the specified topic filter
    retainer reindex status# Show reindex status
    retainer reindex start [force] # Generate new retainer topic indices config settings.
       # Pass true as <Forceto ignore previously started reindexing
    --------------------------------------------------------------------------------------------------------------
    status # Show broker status
    --------------------------------------------------------------------------------------------------------------
    broker # Show broker version, uptime and description
    broker stats   # Show broker statistics of clients, topics, subscribers
    broker metrics # Show broker metrics
    --------------------------------------------------------------------------------------------------------------
    cluster join <Node   # Join the cluster
    cluster leave  # Leave the cluster
    cluster force-leave <Node# Force the node leave from cluster
    cluster status [--json]# Cluster status
    --------------------------------------------------------------------------------------------------------------
    clients list# List all clients
    clients show <ClientId# Show a client
    clients kick <ClientId# Kick out a client
    --------------------------------------------------------------------------------------------------------------
    topics list # List all topics
    topics show <Topic# Show a topic
    --------------------------------------------------------------------------------------------------------------
    subscriptions list # List all subscriptions
    subscriptions show <ClientId # Show subscriptions of a client
    subscriptions add <ClientId<Topic<QoS# Add a static subscription manually
    subscriptions del <ClientId<Topic  # Delete a static subscription manually
    --------------------------------------------------------------------------------------------------------------
    plugins <command[Name-Vsn]  # e.g. 'start emqx_plugin_template-5.0-rc.1'
    plugins list  # List all installed plugins
    plugins describe  Name-Vsn# Describe an installed plugins
    plugins install   Name-Vsn# Install a plugin package placed
      # in plugin'sinstall_dir
    plugins uninstall Name-Vsn# Uninstall a plugin. NOTE: it deletes
      # all files in install_dir/Name-Vsn
    plugins start Name-Vsn# Start a plugin
    plugins stop  Name-Vsn# Stop a plugin
    plugins restart   Name-Vsn# Stop then start a plugin
    plugins disable   Name-Vsn# Disable auto-boot
    plugins enableName-Vsn [Position] # Enable auto-boot at Position in the boot list, where Position could be
      # 'front', 'rear', or 'before Other-Vsn' to specify a relative position.
      # The Position parameter can be used to adjust the boot order.
      # If no Position is given, an already configured plugin
      # will stay at is old position; a newly plugin is appended to the rear
      # e.g. plugins disable foo-0.1.0 front
      #  plugins enable bar-0.2.0 before foo-0.1.0
    --------------------------------------------------------------------------------------------------------------
    vm all # Show info of Erlang VM
    vm load# Show load of Erlang VM
    vm memory  # Show memory of Erlang VM
    vm process # Show process of Erlang VM
    vm io  # Show IO of Erlang VM
    vm ports   # Show Ports of Erlang VM
    --------------------------------------------------------------------------------------------------------------
    mnesia # Mnesia system info
    --------------------------------------------------------------------------------------------------------------
    log set-level <Level # Set the overall log level
    log primary-level  # Show the primary log level now
    log primary-level <Level # Set the primary log level
    log handlers list  # Show log handlers
    log handlers start <HandlerId# Start a log handler
    log handlers stop  <HandlerId# Stop a log handler
    log handlers set-level <HandlerId<Level# Set log level of a log handler
    --------------------------------------------------------------------------------------------------------------
    trace list# List all traces started on local node
    trace start client <ClientId<File[<Level>]# Traces for a client on local node
    trace stop  client <ClientId# Stop tracing for a client on local node
    trace start topic  <Topic   <File[<Level>]# Traces for a topic on local node
    trace stop  topic  <Topic   # Stop tracing for a topic on local node
    trace start ip_address  <IP   <File[<Level>]  # Traces for a client ip on local node
    trace stop  ip_addresss  <IP# Stop tracing for a client ip on local node
    --------------------------------------------------------------------------------------------------------------
    traces list # List all cluster traces started
    traces start <Nameclient <ClientId  # Traces for a client in cluster
    traces start <Nametopic <Topic  # Traces for a topic in cluster
    traces start <Nameip_address <IPAddr# Traces for a IP in cluster
    traces stop  <Name# Stop trace in cluster
    traces delete  <Name  # Delete trace in cluster
    --------------------------------------------------------------------------------------------------------------
    listeners  # List listeners
    listeners stop<Identifier# Stop a listener
    listeners start   <Identifier# Start a listener
    listeners restart <Identifier# Restart a listener
    --------------------------------------------------------------------------------------------------------------
    authz cache-clean all # Clears authorization cache on all nodes
    authz cache-clean node <Node# Clears authorization cache on given node
    authz cache-clean <ClientId # Clears authorization cache for given client
    --------------------------------------------------------------------------------------------------------------
    pem_cache clean all # Clears x509 certificate cache on all nodes
    pem_cache clean node <Node# Clears x509 certificate cache on given node
    --------------------------------------------------------------------------------------------------------------
    olp status  # Return OLP status if system is overloaded
    olp enable  # Enable overload protection
    olp disable # Disable overload protection
    --------------------------------------------------------------------------------------------------------------
    gateway list # List all gateway
    gateway lookup <Name   # Lookup a gateway detailed information
    gateway load   <Name<JsonConf# Load a gateway with config
    gateway unload <Name   # Unload the gateway
    gateway stop   <Name   # Stop the gateway
    gateway start  <Name   # Start the gateway
    --------------------------------------------------------------------------------------------------------------
    gateway-registry list # List all registered gateways
    --------------------------------------------------------------------------------------------------------------
    gateway-clients list   <Name   # List all clients for a gateway
    gateway-clients lookup <Name<ClientId# Lookup the Client Info for specified client
    gateway-clients kick   <Name<ClientId# Kick out a client
    --------------------------------------------------------------------------------------------------------------
    gateway-metrics <Name# List all metrics for a gateway
    --------------------------------------------------------------------------------------------------------------
    rules list  # List rules
    rules show <RuleID# Show a rule

# HTTP API #
EMQX 提供了管理监控 REST API，这些 API 遵循 OpenAPI (Swagger) 3.0 规范。

EMQX 服务启动后，您可以访问 http://localhost:18083/api-docs/index.html 来 查看 API 的文档。还可以直接在 Swagger UI 上尝试执行一些 API。

/api-docs 端点不需要登录，如果需要进一步操作，您需要完成一些基本的配置工作。



![相对路径的图片](./imgs/eqmx_api_doc.png)





本章节指导您完成 API 调用前的准备操作。

#修改默认密码
EMQX 的 HTTP API 默认的访问用户名是 admin 密码是 public。 默认密码建议您立即修改。

修改默认密码，可以通过 emqx.conf 配置文件中加入，或修改 dashboard.default_password。 这个配置项会被用于初始化默认用户的配置。 您也可以通过配置 EMQX_DASHBOARD__DEFAULT_PASSWORD 来对这个参数初始化。

注意

EMQX 的管理员用户名和密码是保存在内置数据库中的。 一旦这个数据库初始化完成之后，再去修改配置文件或环境变量中的默认密码将不会生效。

如果需要在初始化之后对默认用户的密码进行修改，可以使用如下命令行。 emqx ctl admins passwd admin new-password

#创建管理员账户
#用户
初始化了默认用户 (默认是 admin) 的登录密码之后，就可以创建其他的用户了。 创建的渠道有三个，从仪表盘的用户管理界面，REST API，和命令行工具 emqx_ctl。

注意

所有的用户都有管理员权限。 也就是说，EMQX现阶段不提供基于角色的权限管理能力。

如果需要创建一些脚本调用等用户进行 HTTP API 的访问，建议创建 API Key 。



----------

# MQTT 协议快速体验 #

### MQTT 连接 ###

在使用 MQTT 协议进行通信之前，需要先建立一个 MQTT 连接，连接由客户端向服务器端发起。

### MQTT 客户端 ###
任何运行了 MQTT 客户端库的程序或设备都是一个 MQTT 客户端，例如：使用了 MQTT 的即时通讯 APP 是一个客户端，使用 MQTT 上报数据的各种传感器设备是一个客户端，以及各种 MQTT 测试工具也是一个客户端。

目前，基本所有的编程语言都有成熟的开源 MQTT 客户端库，读者可参考 EMQ 整理的 MQTT 客户端库大全选择一个合适的客户端库来构建满足自身业务需求的 MQTT 客户端。也可直接访问 EMQ 提供的 MQTT 客户端编程系列博客，学习如何在 Java、Python、PHP、Node.js 等编程语言中使用 MQTT。


## MQTT 服务器 ##
MQTT 服务器负责接收客户端发起的连接，并将客户端发送的消息转发到另外一些符合条件的客户端。一个成熟的 MQTT 服务器可支持海量的客户端连接及百万级的消息吞吐，帮助物联网业务提供商专注于业务功能并快速创建一个可靠的 MQTT 应用。




- 官方的服务器信息如下：

		Broker： broker.emqx.io
		TCP Port： 1883
		Websocket Port： 8083

- 自己的MQTT服务器信息如下
 
		Broker： 192.168.10.102
		TCP Port： 1883
		Websocket Port： 8083

## 使用MQTTX进行消息的订阅和发布测试 ##

![](./imgs/mqtt_pub_sub_01.png)

![](./imgs/mqtt_pub_sub_02.png)

![](./imgs/mqtt_pub_sub_03.png)