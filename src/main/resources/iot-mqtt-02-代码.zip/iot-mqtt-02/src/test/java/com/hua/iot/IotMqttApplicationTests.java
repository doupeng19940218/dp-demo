package com.hua.iot;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.hua.iot.domain.IOTSensor;
import com.hua.iot.entity.IOTDeviceDetail;
import com.hua.iot.service.IOTDeviceService;
import com.hua.iot.service.IOTSensorService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.List;
import java.util.regex.Pattern;

@SpringBootTest
class IotMqttApplicationTests {

    @Autowired
    IOTDeviceService deviceService;
    @Autowired
    IOTSensorService sensorService;

    @Test
    void contextLoads() {
    }

    @Test
    void testTopic() {
        String topic = "iot/deviceId/332244/sensorTag/co2";

        Pattern pattern = Pattern.compile("^iot/deviceId/\\d{1,10}/sensorTag/*");
        boolean ok = pattern.matcher(topic).matches();
        System.out.println(ok);

        String[] topicArr = topic.split("/");
        String deviceId = topicArr[2];
        String sensorTag = topicArr[4];
        System.out.println(deviceId + sensorTag);

    }

    @Test
    void testMyBatis() {
        IOTDeviceDetail deviceDetail = deviceService.getDeviceDetailByDeviceId(10000001);
        List<IOTSensor> sensorList = deviceDetail.getSensorList();
        for(IOTSensor sensor: sensorList){
            System.out.println(sensor.toString());
        }
    }

    private void testQueryDeviceDetail(){
        IOTDeviceDetail deviceDetail =  deviceService.getDeviceDetailByDeviceId(10000001);
        System.out.println(deviceDetail.getDeviceName());
        List<IOTSensor> sensorList = deviceDetail.getSensorList();
        for(IOTSensor sensor:sensorList)
            System.out.println(sensor.toString());
    }


    private void testQuerySensor() {
        System.out.println("==========> Get All Sensors ==============>");
        List<IOTSensor> iotSensors = sensorService.list();
        for (IOTSensor sensor : iotSensors)
            System.out.println(sensor.toString());

        System.out.println("==========> Get Latest Sensor Value ==============>");
        IOTSensor sensor = sensorService.getLatestSensorVal(10000001, "co2");
        System.out.println(sensor.toString());
    }

}
