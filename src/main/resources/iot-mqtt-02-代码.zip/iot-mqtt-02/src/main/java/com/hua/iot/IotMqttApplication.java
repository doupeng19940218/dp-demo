package com.hua.iot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IotMqttApplication {

    public static void main(String[] args) {
        SpringApplication.run(IotMqttApplication.class, args);
    }

}
