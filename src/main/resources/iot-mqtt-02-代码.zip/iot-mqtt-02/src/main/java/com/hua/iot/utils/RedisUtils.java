package com.hua.iot.utils;

import org.springframework.dao.DataAccessException;
import org.springframework.data.geo.*;
import org.springframework.data.redis.connection.DataType;
import org.springframework.data.redis.connection.RedisConnection;
import org.springframework.data.redis.connection.RedisGeoCommands;
import org.springframework.data.redis.core.*;
import org.springframework.data.redis.domain.geo.BoundingBox;
import org.springframework.data.redis.domain.geo.GeoReference;
import org.springframework.data.redis.domain.geo.GeoShape;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;

import javax.annotation.Resource;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.TimeUnit;

/**
 * Create By Spring-2022/11/6
 */

@Component
public final class RedisUtils {

    @Resource
    private RedisTemplate<String, Object> redisTemplate;

    // =============================common============================

    /**
     * 使用正则匹配，查询有没有匹配的key
     * @param pattern
     * @return
     */
    public Set<String> keys(String pattern){
        return redisTemplate.keys(pattern);
    }


    /**
     * 指定缓存失效时间
     *
     * @param key  键
     * @param time 时间(秒)
     */
    public boolean expire(String key, long time, TimeUnit timeUnit) {
        try {
            if (time > 0) {
                redisTemplate.expire(key, time, timeUnit);
            }
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }


    /**
     * EXPIREAT key unix-time-seconds 设置具体的过期时间
     *
     * @param key  键
     * @param date 日期
     * @return
     */
    public boolean expireAt(String key, Date date) {
        return Boolean.TRUE.equals(redisTemplate.expireAt(key, date));
    }


    /**
     * 根据key 获取过期时间
     *
     * @param key 键 不能为null
     * @return 时间(秒) 返回0代表为永久有效
     */
    public long getExpire(String key) {
        return redisTemplate.getExpire(key, TimeUnit.SECONDS);
    }


    /**
     * 判断key是否存在
     *
     * @param key 键
     * @return true 存在 false不存在
     */
    public boolean hasKey(String key) {
        try {
            return Boolean.TRUE.equals(redisTemplate.hasKey(key));
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }


    /**
     * 序列化 key
     *
     * @param key 键
     * @return key 对应的字节流
     */
    public byte[] dump(String key) {
        return redisTemplate.dump(key);
    }

    /**
     * 移除 key 的过期时间，key 将持久保持
     *
     * @param key 键
     * @return
     */
    public boolean persist(String key) {
        Boolean persist = redisTemplate.persist(key);
        return Boolean.TRUE.equals(persist);
    }


    /**
     * 修改key 的名称
     *
     * @param oldkey 旧 key
     * @param newkey 新 key
     * @return ERR no such key : false    Integer 1: true
     */
    public boolean renameKey(String oldkey, String newkey) {
        return Boolean.TRUE.equals(redisTemplate.renameIfAbsent(oldkey, newkey));
    }


    /**
     * 返回 key 所储存的值的类型。
     *
     * @param key
     * @return
     */
    public DataType type(String key) {
        return redisTemplate.type(key);
    }


    /**
     * 删除缓存
     *
     * @param key 可以传一个值 或多个
     */
    @SuppressWarnings("unchecked")
    public void del(String... key) {
        if (key != null && key.length > 0) {
            if (key.length == 1) {
                redisTemplate.delete(key[0]);
            } else {
                redisTemplate.delete((Collection<String>) CollectionUtils.arrayToList(key));
            }
        }
    }


    // ============================String=============================

    /**
     * 普通缓存获取
     *
     * @param key 键
     * @return 值
     */
    public Object get(String key) {
        return key == null ? null : redisTemplate.opsForValue().get(key);
    }

    /**
     * 返回 key 中字符串值的子串
     *
     * @return 127.0.0.1:6379> get name
     * "spring"
     * 127.0.0.1:6379> GETRANGE name 0 3
     * "spri"  返回索从 0 开始到 3
     * 127.0.0.1:6379>
     */
    public String getRange(String key, long start, long end) {
        return redisTemplate.opsForValue().get(key, start, end);
    }

    /**
     * 获取 key 中的旧值，并设置新值
     *
     * @return key 中的旧值
     * 127.0.0.1:6379> get name
     * "spring"
     * 127.0.0.1:6379> GETSET name springhua
     * "spring"
     * 127.0.0.1:6379> get name
     * "springhua"
     */
    public Object getAndSet(String key, Object val) {
        return redisTemplate.opsForValue().getAndSet(key, val);
    }

    /**
     * 获取并移除 key
     *
     * @param key
     * @return
     */
    public Object getAndDelete(String key) {
        return redisTemplate.opsForValue().getAndDelete(key);
    }

    /**
     * 获取多个键的值
     *
     * @param key，不定长键
     * @return
     */
    public List<Object> multiGet(String... key) {
        List<String> keyList = Arrays.asList(key);
        return redisTemplate.opsForValue().multiGet(keyList);
    }

    /**
     * 普通缓存放入
     *
     * @param key   键
     * @param value 值
     * @return true成功 false失败
     */

    public boolean set(String key, Object value) {
        try {
            redisTemplate.opsForValue().set(key, value);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }


    /**
     * 将值 value 关联到 key ，并将 key 的过期时间设为 timeout
     *
     * @param key
     * @param value
     * @param timeout 过期时间
     * @param unit    时间单位, 天:TimeUnit.DAYS 小时:TimeUnit.HOURS 分钟:TimeUnit.MINUTES
     *                秒:TimeUnit.SECONDS 毫秒:TimeUnit.MILLISECONDS
     */
    public void setEx(String key, String value, long timeout, TimeUnit unit) {
        redisTemplate.opsForValue().set(key, value, timeout, unit);
    }


    /**
     * 普通缓存放入并设置时间
     *
     * @param key   键
     * @param value 值
     * @param time  时间(秒) time要大于0 如果time小于等于0 将设置无限期
     * @return true成功 false 失败
     */

    public boolean set(String key, Object value, long time) {
        try {
            if (time > 0) {
                redisTemplate.opsForValue().set(key, value, time, TimeUnit.SECONDS);
            } else {
                set(key, value);
            }
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }


    /**
     * 只有在 key 不存在时设置 key 的值
     *
     * @param key
     * @param value
     * @return 之前已经存在返回false, 不存在返回true
     * 127.0.0.1:6379> get name
     * "spring"
     * 127.0.0.1:6379> SETNX name springhua
     * (integer) 0
     * 127.0.0.1:6379> get name
     * "spring"
     * 127.0.0.1:6379> SETNX fullname springhua
     * (integer) 1
     */
    public boolean setIfAbsent(String key, String value) {
        return Boolean.TRUE.equals(redisTemplate.opsForValue().setIfAbsent(key, value));
    }

    /**
     * 用 value 参数覆写给定 key 所储存的字符串值，从偏移量 offset 开始
     *
     * @param key
     * @param value
     * @param offset 从指定位置开始覆写
     */
    public void setRange(String key, String value, long offset) {
        redisTemplate.opsForValue().set(key, value, offset);
    }


    /**
     * 返回字符串的长度
     *
     * @param key
     * @return
     */
    public Long size(String key) {
        return redisTemplate.opsForValue().size(key);
    }

    /**
     * 批量添加
     *
     * @param maps
     */
    public void multiSet(Map<? extends String, ?> maps) {
        redisTemplate.opsForValue().multiSet(maps);
    }


    /**
     * 递增
     *
     * @param key   键
     * @param delta 要增加几(大于0)
     */
    public long incr(String key, long delta) {
        if (delta < 0) {
            throw new RuntimeException("递增因子必须大于0");
        }
        return redisTemplate.opsForValue().increment(key, delta);
    }


    /**
     * 递减
     *
     * @param key   键
     * @param delta 要减少几(小于0)
     */
    public long decr(String key, long delta) {
        if (delta < 0) {
            throw new RuntimeException("递减因子必须大于0");
        }
        return redisTemplate.opsForValue().decrement(key, delta);
    }


    /**
     * 追加到末尾
     *
     * @param key
     * @param value
     * @return
     */
    public Integer append(String key, String value) {
        return redisTemplate.opsForValue().append(key, value);
    }

    // ================================ Map  Hash 操作=================================

    /**
     * HashGet 获取存储在哈希表中指定字段的值。
     *
     * @param key  键 不能为null
     * @param item 项 不能为null
     */
    public Object hget(String key, String item) {
        return redisTemplate.opsForHash().get(key, item);
    }

    /**
     * 获取所有给定字段的值
     *
     * @param key
     * @param fields
     * @return 返回多个属性的值
     */
    public List<Object> hmget(String key, Collection<Object> fields) {
        return redisTemplate.opsForHash().multiGet(key, fields);
    }

    /**
     * 获取hashKey对应的所有键值
     *
     * @param key 键
     * @return 对应的多个键值
     */
    public Map<Object, Object> hGetAll(String key) {
        return redisTemplate.opsForHash().entries(key);
    }

    /**
     * 获取所有的Key
     *
     * @param key
     * @return 127.0.0.1:6379> HKEYS stu
     * 1) "name"
     * 2) "age"
     * 3) "score"
     * 4) "sex"
     * 5) "height
     */
    public Set<Object> hKeys(String key) {
        return redisTemplate.opsForHash().keys(key);
    }

    /**
     * 获取所有的 values
     *
     * @param key
     * @return
     */
    public List<Object> hValues(String key) {
        return redisTemplate.opsForHash().values(key);
    }


    /**
     * 向一张hash表中放入数据,如果不存在将创建
     *
     * @param key   键
     * @param item  项
     * @param value 值
     * @return true 成功 false失败
     */
    public boolean hset(String key, String item, Object value) {
        try {
            redisTemplate.opsForHash().put(key, item, value);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * 向一张hash表中放入数据,如果不存在将创建
     *
     * @param key   键
     * @param item  项
     * @param value 值
     * @param time  时间(秒) 注意:如果已存在的hash表有时间,这里将会替换原有的时间
     * @return true 成功 false失败
     */
    public boolean hset(String key, String item, Object value, long time, TimeUnit timeUnit) {
        try {
            redisTemplate.opsForHash().put(key, item, value);
            if (time > 0) {
                expire(key, time, timeUnit);
            }
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }


    /**
     * 仅当hashKey不存在时才设置
     *
     * @param key
     * @param hashKey
     * @param value
     * @return 127.0.0.1:6379> HSETNX stu name hh    不存在，则创建成功
     * (integer) 1
     * 127.0.0.1:6379> HGETALL stu
     * 1) "name"
     * 2) "hh"
     * 127.0.0.1:6379> HSETNX stu name newhh 已经存在了 name，则创建失败
     * (integer) 0
     */
    public Boolean hsetnx(String key, String hashKey, String value) {
        return redisTemplate.opsForHash().putIfAbsent(key, hashKey, value);
    }

    /**
     * HashSet
     *
     * @param key 键
     * @param map 对应多个键值
     */
    public void hmset(String key, Map<String, Object> map) {
        redisTemplate.opsForHash().putAll(key, map);
    }


    /**
     * HashSet 并设置时间
     *
     * @param key  键
     * @param map  对应多个键值
     * @param time 时间(秒)
     * @return true成功 false失败
     */
    public boolean hmset(String key, Map<String, Object> map, long time, TimeUnit timeUnit) {
        try {
            redisTemplate.opsForHash().putAll(key, map);
            if (time > 0) {
                expire(key, time, timeUnit);
            }
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }


    /**
     * 删除hash表中的值
     *
     * @param key      键 不能为null
     * @param hashKeys 项 可以使多个 不能为null
     */
    public void hdel(String key, Object... hashKeys) {
        redisTemplate.opsForHash().delete(key, hashKeys);
    }


    /**
     * 判断hash表中是否有该项的值
     *
     * @param key     键 不能为null
     * @param hashKey 项 不能为null
     * @return true 存在 false不存在
     */
    public boolean hHasKey(String key, Object hashKey) {
        return redisTemplate.opsForHash().hasKey(key, hashKey);
    }


    /**
     * hash递增 如果不存在,就会创建一个 并把新增后的值返回
     *
     * @param key  键
     * @param item 项
     * @param by   要增加几(大于0)
     */
    public double hIncr(String key, String item, double by) {
        return redisTemplate.opsForHash().increment(key, item, by);
    }

    /**
     * 为哈希表 key 中的指定字段的整数值加上增量 increment
     *
     * @param key
     * @param field
     * @param increment
     * @return
     */
    public Long hIncr(String key, Object field, long increment) {
        return redisTemplate.opsForHash().increment(key, field, increment);
    }


    /**
     * hash递减
     *
     * @param key  键
     * @param item 项
     * @param by   要减少记(小于0)
     */
    public double hDecr(String key, String item, double by) {
        return redisTemplate.opsForHash().increment(key, item, -by);
    }

    /**
     * 获取 hash表中，某一个 key 的长度
     *
     * @param key
     * @param hashKey
     * @return
     */
    public Long hStrlen(String key, Object hashKey) {
        return redisTemplate.opsForHash().lengthOfValue(key, hashKey);
    }

    /**
     * 迭代哈希表中的键值对
     *
     * @param key
     * @param options
     * @return
     */
    public Cursor<Map.Entry<Object, Object>> hScan(String key, ScanOptions options) {
        return redisTemplate.opsForHash().scan(key, options);
    }


    // ============================ SET =============================
    //  Redis 的 Set 是 String 类型的无序集合。集合成员是唯一的，这就意味着集合中不能出现重复的数据
    //  集合对象的编码可以是 intset 或者 hashtable。
    //  Redis 中集合是通过哈希表实现的，所以添加，删除，查找的复杂度都是 O(1)。
    //  集合中最大的成员数为 232 - 1 (4294967295, 每个集合可存储40多亿个成员)。
    // ============================ SET =============================

    /**
     * 向集合添加一个或多个成员
     *
     * @param key    键
     * @param values 值 可以是多个
     * @return 成功个数
     */
    public long sAddMember(String key, Object... values) {
        try {
            return redisTemplate.opsForSet().add(key, values);
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }

    /**
     * 根据key获取Set中的所有值
     *
     * @param key 键
     */
    public Set<Object> sGetAllMembers(String key) {
        try {
            return redisTemplate.opsForSet().members(key);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }


    /**
     * 根据value从一个set中查询,是否存在
     *
     * @param key   键
     * @param value 值
     * @return true 存在 false不存在
     */
    public boolean sContainsMember(String key, Object value) {
        try {
            return Boolean.TRUE.equals(redisTemplate.opsForSet().isMember(key, value));
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * 判断集合是否包含value
     *
     * @param key
     * @param value
     * @return
     */
    public Boolean sIsMember(String key, Object value) {
        return sContainsMember(key, value);
    }


    /**
     * 将set数据放入缓存
     *
     * @param key    键
     * @param time   时间(秒)
     * @param values 值 可以是多个
     * @return 成功个数
     */
    public long sSetMemberAndTime(String key, long time, TimeUnit timeUnit, Object... values) {
        try {
            Long count = redisTemplate.opsForSet().add(key, values);
            if (time > 0) {
                expire(key, time, timeUnit);
            }
            return count;
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }


    /**
     * 获取集合的成员数
     *
     * @param key 键
     */
    public long sSize(String key) {
        try {
            return redisTemplate.opsForSet().size(key);
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }


    /**
     * 移除值为value的
     *
     * @param key    键
     * @param values 值 可以是多个
     * @return 移除的个数
     */

    public long sRemoveMembers(String key, Object... values) {
        try {
            return redisTemplate.opsForSet().remove(key, values);
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }


    /**
     * 移除并返回集合的一个随机元素
     *
     * @param key
     * @return
     */
    public Object sPopMember(String key) {
        return redisTemplate.opsForSet().pop(key);
    }


    /**
     * 将元素 value从一个集合移到另一个集合
     *
     * @param key
     * @param value
     * @param destKey
     * @return
     */
    public Boolean sMoveMember(String key, Object value, String destKey) {
        return redisTemplate.opsForSet().move(key, value, destKey);
    }


    /**
     * 获取两个集合的交集, 找相同元素
     *
     * @param key
     * @param otherKey
     * @return
     */
    public Set<Object> sIntersect(String key, String otherKey) {
        return redisTemplate.opsForSet().intersect(key, otherKey);
    }


    /**
     * 获取key集合与多个集合的交集
     *
     * @param key
     * @param otherKeys
     * @return
     */
    public Set<Object> sIntersect(String key, Collection<String> otherKeys) {
        return redisTemplate.opsForSet().intersect(key, otherKeys);
    }

    /**
     * key集合与otherKey集合的交集存储到destKey集合中
     *
     * @param key
     * @param otherKey
     * @param destKey  要存储目的的集合名
     * @return
     */
    public Long sIntersectAndStore(String key, String otherKey, String destKey) {
        return redisTemplate.opsForSet().intersectAndStore(key, otherKey, destKey);
    }

    /**
     * key集合与多个集合的交集存储到destKey集合中
     *
     * @param key
     * @param otherKeys 其它集合
     * @param destKey   要存储目的的集合名
     * @return
     */
    public Long sIntersectAndStore(String key, Collection<String> otherKeys, String destKey) {
        return redisTemplate.opsForSet().intersectAndStore(key, otherKeys, destKey);
    }

    /**
     * 获取两个集合的并集
     *
     * @param key
     * @param otherKeys
     * @return
     */
    public Set<Object> sUnion(String key, String otherKeys) {
        return redisTemplate.opsForSet().union(key, otherKeys);
    }

    /**
     * 获取key集合与多个集合的并集
     *
     * @param key
     * @param otherKeys
     * @return
     */
    public Set<Object> sUnion(String key, Collection<String> otherKeys) {
        return redisTemplate.opsForSet().union(key, otherKeys);
    }

    /**
     * key集合与otherKey集合的并集存储到destKey中
     *
     * @param key
     * @param otherKey
     * @param destKey
     * @return
     */
    public Long sUnionAndStore(String key, String otherKey, String destKey) {
        return redisTemplate.opsForSet().unionAndStore(key, otherKey, destKey);
    }

    /**
     * key集合与多个集合的并集存储到destKey中
     *
     * @param key
     * @param otherKeys
     * @param destKey
     * @return
     */
    public Long sUnionAndStore(String key, Collection<String> otherKeys, String destKey) {
        return redisTemplate.opsForSet().unionAndStore(key, otherKeys, destKey);
    }


    /**
     * 获取两个集合的差集
     *
     * @param key
     * @param otherKey
     * @return
     */
    public Set<Object> sDifference(String key, String otherKey) {
        return redisTemplate.opsForSet().difference(key, otherKey);
    }

    /**
     * 获取key集合与多个集合的差集
     *
     * @param key
     * @param otherKeys
     * @return
     */
    public Set<Object> sDifference(String key, Collection<String> otherKeys) {
        return redisTemplate.opsForSet().difference(key, otherKeys);
    }

    /**
     * key集合与otherKey集合的差集存储到destKey中
     *
     * @param key
     * @param otherKey
     * @param destKey
     * @return
     */
    public Long sDifferenceAndStore(String key, String otherKey, String destKey) {
        return redisTemplate.opsForSet().differenceAndStore(key, otherKey, destKey);
    }

    /**
     * key集合与多个集合的差集存储到destKey中
     *
     * @param key
     * @param otherKeys
     * @param destKey
     * @return
     */
    public Long sDifferenceAndStore(String key, Collection<String> otherKeys, String destKey) {
        return redisTemplate.opsForSet().differenceAndStore(key, otherKeys, destKey);
    }

    /**
     * 随机获取集合中的一个元素
     *
     * @param key
     * @return
     */
    public Object sRandomMember(String key) {
        return redisTemplate.opsForSet().randomMember(key);
    }

    /**
     * 随机获取集合中count个元素
     *
     * @param key
     * @param count
     * @return
     */
    public List<Object> sRandomMembers(String key, long count) {
        return redisTemplate.opsForSet().randomMembers(key, count);
    }

    /**
     * 随机获取集合中count个元素并且去除重复的
     *
     * @param key
     * @param count
     * @return
     */
    public Set<Object> sDistinctRandomMembers(String key, long count) {
        return redisTemplate.opsForSet().distinctRandomMembers(key, count);
    }

    /**
     * 扫描
     *
     * @param key     key
     * @param options 扫描参数选项
     * @return 游标
     */
    public Cursor<Object> sScan(String key, ScanOptions options) {
        return redisTemplate.opsForSet().scan(key, options);
    }

    // ===============================  LIST ===============================
    // Redis列表是简单的字符串列表，按照插入顺序排序。你可以添加一个元素到列表的头部（左边）或者尾部（右边）
    //一个列表最多可以包含 232 - 1 个元素 (4294967295, 每个列表超过40亿个元素)。
    // 127.0.0.1:6379> RPUSH numList 0 2 4 6 8 10 12 100 ，也可以 LPUSH 每个元素都插在队头
    //(integer) 8
    //127.0.0.1:6379> RPUSH strList aa bb cc dd ee ff gg
    //(integer) 7
    // =====================================================================


    /**
     * 将list队尾放入缓存 , 像 存入  0  2  4  6  8 就是这样的顺序  (头） 0 -> 2 -> 4 -> 6 -> 8 （尾）
     *
     * @param key   键
     * @param value 值
     */
    public boolean lRightAdd(String key, Object value) {
        try {
            redisTemplate.opsForList().rightPush(key, value);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }


    /**
     * 将list队尾放入缓存
     *
     * @param key   键
     * @param value 值
     * @param time  时间(秒)
     */
    public boolean lRightAdd(String key, Object value, long time, TimeUnit timeUnit) {
        try {
            redisTemplate.opsForList().rightPush(key, value);
            if (time > 0) {
                expire(key, time, timeUnit);
            }
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }

    }

    /**
     * 将list队尾放入缓存
     *
     * @param key   键
     * @param value 值
     * @return
     */
    public boolean lRightAddAll(String key, List<Object> value) {
        try {
            redisTemplate.opsForList().rightPushAll(key, value);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * 将list队尾放入缓存
     *
     * @param key   键
     * @param value 值
     * @param time  时间(秒)
     * @return
     */
    public boolean lRightAddAll(String key, List<Object> value, long time, TimeUnit timeUnit) {
        try {
            redisTemplate.opsForList().rightPushAll(key, value);
            if (time > 0) {
                expire(key, time, timeUnit);
            }
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    /**
     * 当list存在的时候才加入
     *
     * @param key
     * @param value
     * @return
     */
    public Long lRightAddIfPresent(String key, Object value) {
        return redisTemplate.opsForList().rightPushIfPresent(key, value);
    }

    /**
     * 存储在list头部
     *
     * @param key
     * @param value
     * @return 总长度
     */
    public Long lLeftPush(String key, Object value) {
        return redisTemplate.opsForList().leftPush(key, value);
    }

    /**
     * 如果pivot存在,再pivot前面添加
     *
     * @param key
     * @param pivot
     * @param value
     * @return
     */
    public Long lInsertBefore(String key, String pivot, String value) {
        return redisTemplate.opsForList().leftPush(key, pivot, value);
    }

    public Long lInsertAfter(String key, String pivot, String value) {
        return redisTemplate.opsForList().rightPush(key, pivot, value);
    }

    /**
     * 存储在list头部，一次存多个元素
     *
     * @param key
     * @param value
     * @return
     */
    public Long lLeftPushAll(String key, Object... value) {
        return redisTemplate.opsForList().leftPushAll(key, value);
    }

    /**
     * @param key
     * @param value
     * @return
     */
    public Long lLeftPushAll(String key, Collection<Object> value) {
        return redisTemplate.opsForList().leftPushAll(key, value);
    }

    /**
     * 当list存在的时候才加入
     *
     * @param key
     * @param value
     * @return
     */
    public Long lLeftPushIfPresent(String key, Object value) {
        return redisTemplate.opsForList().leftPushIfPresent(key, value);
    }


    /**
     * 通过索引设置列表元素的值
     *
     * @param key
     * @param index 位置
     * @param value 新值
     */
    public void lSet(String key, long index, String value) {
        if (index >= lLen(key) - 1) {
            return;
        }
        redisTemplate.opsForList().set(key, index, value);
    }

    /**
     * 通过索引 获取list中的值
     *
     * @param key   键
     * @param index 索引 index>=0时， 0 表头，1 第二个元素，依次类推；index<0时，-1，表尾，-2倒数第二个元素，依次类推
     */
    public Object lIndex(String key, long index) {
        try {
            return redisTemplate.opsForList().index(key, index);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }


    /**
     * 获取list缓存的内容
     *
     * @param key   键
     * @param start 开始
     * @param end   结束 0 到 -1代表所有值
     */
    public List<Object> lGet(String key, long start, long end) {
        try {
            return redisTemplate.opsForList().range(key, start, end);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }


    /**
     * 获取list缓存的长度
     *
     * @param key 键
     */
    public long lLen(String key) {
        try {
            return redisTemplate.opsForList().size(key);
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }


    /**
     * 移出并获取列表的第一个元素
     *
     * @param key
     * @return 删除的元素
     */
    public Object lLeftPop(String key) {
        return redisTemplate.opsForList().leftPop(key);
    }

    /**
     * 阻塞式的移出并获取列表的第一个元素， 如果列表没有元素会阻塞列表直到等待超时或发现可弹出元素为止
     *
     * @param key
     * @param timeout 等待时间
     * @param unit    时间单位
     * @return
     */
    public Object lBlockedLeftPop(String key, long timeout, TimeUnit unit) {
        return redisTemplate.opsForList().leftPop(key, timeout, unit);
    }

    /**
     * 移除并获取列表最后一个元素
     *
     * @param key
     * @return 删除的元素
     */
    public Object lRightPop(String key) {
        return redisTemplate.opsForList().rightPop(key);
    }

    /**
     * 阻塞式的移出并获取列表的第一个元素， 如果列表没有元素会阻塞列表直到等待超时或发现可弹出元素为止
     *
     * @param key
     * @param timeout 等待时间
     * @param unit    时间单位
     * @return
     */
    public Object lBlockedRightPop(String key, long timeout, TimeUnit unit) {
        return redisTemplate.opsForList().rightPop(key, timeout, unit);
    }

    /**
     * 移除列表的最后一个元素，并将该元素添加到另一个列表并返回
     *
     * @param sourceKey      源
     * @param destinationKey 目的
     * @return
     */
    public Object lRightPopAndLeftPush(String sourceKey, String destinationKey) {
        return redisTemplate.opsForList().rightPopAndLeftPush(sourceKey, destinationKey);
    }

    /**
     * 从列表中弹出一个值，将弹出的元素插入到另外一个列表中并返回它； 如果列表没有元素会阻塞列表直到等待超时或发现可弹出元素为止
     *
     * @param sourceKey
     * @param destinationKey
     * @param timeout
     * @param unit
     * @return
     */
    public Object lBlockedRightPopAndLeftPush(String sourceKey, String destinationKey, long timeout, TimeUnit unit) {
        return redisTemplate.opsForList().rightPopAndLeftPush(sourceKey, destinationKey, timeout, unit);
    }


    /**
     * 根据索引修改list中的某条数据
     *
     * @param key   键
     * @param index 索引
     * @param value 值
     * @return
     */

    public boolean lUpdateIndex(String key, long index, Object value) {
        try {
            redisTemplate.opsForList().set(key, index, value);
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public Long lPos(String key, Object element) {
        return redisTemplate.opsForList().indexOf(key, element);
    }


    /**
     * 移除N个值为value
     *
     * @param key   键
     * @param count 移除多少个
     * @param value 值
     * @return 移除的个数
     */

    public long lRemove(String key, long count, Object value) {
        try {
            Long remove = redisTemplate.opsForList().remove(key, count, value);
            return remove;
        } catch (Exception e) {
            e.printStackTrace();
            return 0;
        }
    }


    /**
     * 裁剪 list
     *
     * @param key   key
     * @param start 起始位置
     * @param end   结束位置
     */
    public void lTrim(String key, long start, long end) {
        redisTemplate.opsForList().trim(key, start, end);
    }


    //================================  ZSET 有序集合  ================================
    //Redis 有序集合和集合一样也是 string 类型元素的集合,且不允许重复的成员。
    //不同的是每个元素都会关联一个 double 类型的分数。redis 正是通过分数来为集合中的成员进行从小到大的排序。
    //有序集合的成员是唯一的,但分数(score)却可以重复。
    //集合是通过哈希表实现的，所以添加，删除，查找的复杂度都是 O(1)。 集合中最大的成员数为 232 - 1 (4294967295, 每个集合可存储40多亿个成员)
    //================================  ZSET 有序集合  ================================

    /**
     * 添加元素,有序集合是按照元素的score值由小到大排列
     *
     * @param key
     * @param value
     * @param score
     * @return
     */
    public Boolean zAdd(String key, String value, double score) {
        return redisTemplate.opsForZSet().add(key, value, score);
    }

    /**
     * 向有序集合中添加多个元素，带有分数的
     *
     * @param key
     * @param values
     * @return
     */
    public Long zAdd(String key, Set<ZSetOperations.TypedTuple<Object>> values) {
        return redisTemplate.opsForZSet().add(key, values);
    }

    /**
     * 向有序集合中添加多个元素，如果原来的 val 已经存在，则会返回失败，只有当不存在时，才会添加成功
     *
     * @param key
     * @param val
     * @param score
     * @return
     */
    public boolean zAddIfAbsent(String key, Object val, double score) {
        return Boolean.TRUE.equals(redisTemplate.opsForZSet().addIfAbsent(key, val, score));
    }

    public Long zAddIfAbsent(String key, Object val, Set<ZSetOperations.TypedTuple<Object>> tuples) {
        return redisTemplate.opsForZSet().addIfAbsent(key, tuples);
    }


    /**
     * 从有序集合 zset 中移除多个元素
     *
     * @param key
     * @param values
     * @return 移除元素的数量
     */
    public Long zRemove(String key, Object... values) {
        return redisTemplate.opsForZSet().remove(key, values);
    }

    /**
     * 增量添加元素的score值，并返回增加后的值
     *
     * @param key
     * @param value
     * @param delta 增量，可以是负值
     * @return
     */
    public Double zIncrementScore(String key, Object value, double delta) {
        return redisTemplate.opsForZSet().incrementScore(key, value, delta);
    }

    /**
     * 返回元素在集合的排名,有序集合是按照元素的score值由小到大排列
     *
     * @param key
     * @param value
     * @return 0表示第一位
     */
    public Long zRank(String key, Object value) {
        return redisTemplate.opsForZSet().rank(key, value);
    }

    /**
     * 返回元素在集合的排名,按元素的score值由大到小排列
     *
     * @param key
     * @param value
     * @return
     */
    public Long zReverseRank(String key, Object value) {
        return redisTemplate.opsForZSet().reverseRank(key, value);
    }

    /**
     * 获取集合的元素, 从小到大排序
     *
     * @param key
     * @param start 开始位置
     * @param end   结束位置, -1查询所有
     * @return
     */
    public Set<Object> zRange(String key, long start, long end) {
        return redisTemplate.opsForZSet().range(key, start, end);
    }

    /**
     * 获取集合的元素, 从小到大排序, 并且把score值也获取
     *
     * @param key
     * @param start
     * @param end
     * @return
     */
    public Set<ZSetOperations.TypedTuple<Object>> zRangeWithScores(String key, long start, long end) {
        return redisTemplate.opsForZSet().rangeWithScores(key, start, end);
    }

    /**
     * 根据Score值查询集合元素
     *
     * @param key
     * @param min score的最小值
     * @param max score的最大值
     * @return 满足条件的集合
     */
    public Set<Object> zRangeByScore(String key, double min, double max) {
        return redisTemplate.opsForZSet().rangeByScore(key, min, max);
    }

    /**
     * 根据Score值查询集合元素, 从小到大排序
     *
     * @param key
     * @param min 最小值
     * @param max 最大值
     * @return
     */
    public Set<ZSetOperations.TypedTuple<Object>> zRangeByScoreWithScores(String key, double min, double max) {
        return redisTemplate.opsForZSet().rangeByScoreWithScores(key, min, max);
    }

    /**
     * @param key    key
     * @param min    最小分数 score
     * @param max    最大分数  score
     * @param offset 类似分页查询,偏移量
     * @param count  获取多少个
     * @return
     */
    public Set<ZSetOperations.TypedTuple<Object>> zRangeByScoreWithScores(String key, double min, double max, long offset, long count) {
        return redisTemplate.opsForZSet().rangeByScoreWithScores(key, min, max, offset, count);
    }

    /**
     * 获取集合的元素, 从大到小排序
     *
     * @param key
     * @param start
     * @param end
     * @return
     */
    public Set<Object> zReverseRange(String key, long start, long end) {
        return redisTemplate.opsForZSet().reverseRange(key, start, end);
    }

    /**
     * 获取集合的元素, 从大到小排序, 并返回score值
     *
     * @param key
     * @param start
     * @param end
     * @return
     */
    public Set<ZSetOperations.TypedTuple<Object>> zReverseRangeWithScores(String key, long start, long end) {
        return redisTemplate.opsForZSet().reverseRangeWithScores(key, start, end);
    }

    /**
     * 根据Score值查询集合元素, 从大到小排序
     *
     * @param key
     * @param min
     * @param max
     * @return
     */
    public Set<Object> zReverseRangeByScore(String key, double min, double max) {
        return redisTemplate.opsForZSet().reverseRangeByScore(key, min, max);
    }

    /**
     * 根据Score值查询集合元素, 从大到小排序
     *
     * @param key
     * @param min
     * @param max
     * @return
     */
    public Set<ZSetOperations.TypedTuple<Object>> zReverseRangeByScoreWithScores(String key, double min, double max) {
        return redisTemplate.opsForZSet().reverseRangeByScoreWithScores(key, min, max);
    }

    /**
     * 逆序，从小到大获取
     *
     * @param key    key
     * @param min    最小分数 score
     * @param max    最大分数  score
     * @param offset 类似分页查询,偏移量
     * @param count  获取多少个
     * @return
     */
    public Set<Object> zReverseRangeByScore(String key, double min, double max, long offset, long count) {
        return redisTemplate.opsForZSet().reverseRangeByScore(key, min, max, offset, count);
    }

    /**
     * 根据score值获取集合元素数量
     *
     * @param key
     * @param min
     * @param max
     * @return
     */
    public Long zCount(String key, double min, double max) {
        return redisTemplate.opsForZSet().count(key, min, max);
    }

    /**
     * 获取集合大小
     *
     * @param key
     * @return
     */
    public Long zSize(String key) {
        return redisTemplate.opsForZSet().size(key);
    }

    /**
     * 获取集合大小
     *
     * @param key
     * @return
     */
    public Long zZCard(String key) {
        return redisTemplate.opsForZSet().zCard(key);
    }

    /**
     * 获取集合中value元素的score值
     *
     * @param key
     * @param value
     * @return
     */
    public Double zScore(String key, Object value) {
        return redisTemplate.opsForZSet().score(key, value);
    }

    /**
     * 移除指定索引位置的成员
     *
     * @param key
     * @param start
     * @param end
     * @return
     */
    public Long zRemoveRange(String key, long start, long end) {
        return redisTemplate.opsForZSet().removeRange(key, start, end);
    }

    /**
     * 根据指定的score值的范围来移除成员
     *
     * @param key
     * @param min
     * @param max
     * @return
     */
    public Long zRemoveRangeByScore(String key, double min, double max) {
        return redisTemplate.opsForZSet().removeRangeByScore(key, min, max);
    }


    /**
     * 差集
     *
     * @param key
     * @param otherKey
     * @return 两个集合中，不一样的元素
     */
    public Set<Object> zDifference(String key, String otherKey) {
        return redisTemplate.opsForZSet().difference(key, otherKey);
    }

    public Set<Object> zDifference(String key, String... otherKeys) {
        return redisTemplate.opsForZSet().difference(key, List.of(otherKeys));
    }

    /**
     * 差集  +  保存
     */
    public Long zDifferenceAndStore(String key, String destKey, String... otherKeys) {
        return redisTemplate.opsForZSet().differenceAndStore(key, List.of(otherKeys), destKey);
    }

    /**
     * 并集 即 合集
     */
    public Set<Object> zUnion(String key, String otherKey) {
        return redisTemplate.opsForZSet().union(key, otherKey);
    }

    public Set<Object> zUnion(String key, String... otherKeys) {
        return redisTemplate.opsForZSet().union(key, List.of(otherKeys));
    }


    /**
     * 获取key和otherKey的并集并存储在destKey中
     */
    public Long zUnionAndStore(String key, String otherKey, String destKey) {
        return redisTemplate.opsForZSet().unionAndStore(key, otherKey, destKey);
    }

    /**
     * 并集 + 保存
     */
    public Long zUnionAndStore(String key, Collection<String> otherKeys, String destKey) {
        return redisTemplate.opsForZSet().unionAndStore(key, otherKeys, destKey);
    }


    /**
     * 交集
     */

    public Set<Object> zIntersect(String key, String otherKey) {
        return redisTemplate.opsForZSet().intersect(key, otherKey);
    }

    public Set<Object> zIntersect(String key, Collection<String> otherKey) {
        return redisTemplate.opsForZSet().intersect(key, otherKey);
    }

    /**
     * 交集 + 保存
     */
    public Long zIntersectAndStore(String key, String otherKey, String destKey) {
        return redisTemplate.opsForZSet().intersectAndStore(key, otherKey, destKey);
    }

    public Long zIntersectAndStore(String key, Collection<String> otherKey, String destKey) {
        return redisTemplate.opsForZSet().intersectAndStore(key, otherKey, destKey);
    }


    /**
     * @param key
     * @param options
     * @return
     */
    public Cursor<ZSetOperations.TypedTuple<Object>> zScan(String key, ScanOptions options) {
        return redisTemplate.opsForZSet().scan(key, options);
    }


    // ===============================HyperLogLog=================================
    // Redis HyperLogLog
    //  Redis 在 2.8.9 版本添加了 HyperLogLog 结构。
    //
    //  Redis HyperLogLog 是用来做基数统计的算法，HyperLogLog 的优点是，在输入元素的数量或者体积非常非常大时，计算基数所需的空间总是固定 的、并且是很小的。
    //
    //  在 Redis 里面，每个 HyperLogLog 键只需要花费 12 KB 内存，就可以计算接近 2^64 个不同元素的基 数。这和计算基数时，元素越多耗费内存就越多的集合形成鲜明对比。
    //
    //  但是，因为 HyperLogLog 只会根据输入元素来计算基数，而不会储存输入元素本身，所以 HyperLogLog 不能像集合那样，返回输入的各个元素。

    // 什么是基数?
    //比如数据集 {1, 3, 5, 7, 5, 7, 8}， 那么这个数据集的基数集为 {1, 3, 5 ,7, 8}, 基数(不重复元素)为5。 基数估计就是在误差可接受的范围内，快速计算基数。

    /**
     * 添加元素
     *
     * @param key
     * @param value
     * @return
     */
    public long pfadd(String key, Object... value) {
        return redisTemplate.opsForHyperLogLog().add(key, value);
    }

    /**
     * 计算集合中，不重复元素的个数，即计算数据集 基数集的个数
     *
     * @param key
     * @return
     */
    public long pfcount(String key) {
        return redisTemplate.opsForHyperLogLog().size(key);
    }

    /**
     * 移除
     *
     * @param key
     */
    public void pfremove(String key) {
        redisTemplate.opsForHyperLogLog().delete(key);
    }

    /**
     * 合并
     *
     * @param key1
     * @param key2
     */
    public void pfmerge(String key1, String key2) {
        redisTemplate.opsForHyperLogLog().union(key1, key2);
    }


    //==============================  Bitmap 位图 =============================

    /**
     * setBit 设置某一位的值（零存）
     *
     * @param key    redis key
     * @param offset 偏移量：从左到右，从0开始，每8位一个字符，若偏移量为8，则为第2个字符的最高位
     * @param value  位的值  true为1，false为0
     * @return
     */
    public Boolean setBit(String key, long offset, boolean value) {
        return redisTemplate.opsForValue().setBit(key, offset, value);
    }

    /**
     * getBit 获取某一位的值（零取）
     *
     * @param key    redis key
     * @param offset 偏移量：从左到右，从0开始，每8位一个字符，若偏移量为8，则为第2个字符的最高位
     * @return
     */
    public Boolean getBit(String key, long offset) {
        return redisTemplate.opsForValue().getBit(key, offset);
    }

    /**
     * bitCount 统计值对应位为1的数量, 可以用来设计签到，这种只有 0  1 的问题
     *
     * @param key redis key
     * @return
     */
    public long bitCount(String key) {
        return redisTemplate.execute(new RedisCallback<Long>() {
            @Override
            public Long doInRedis(RedisConnection connection) throws DataAccessException {
                return connection.bitCount(key.getBytes(StandardCharsets.UTF_8));
            }
        });
    }


    /**
     * bitCount 统计值指定范围（范围为字节范围）对应位为1的数量
     *
     * @param key   redis key
     * @param start 开始字节位置（包含）
     * @param end   结束字节位置（包含）
     * @return
     */
    public Long bitCount(String key, long start, long end) {
        return redisTemplate.execute((RedisCallback<Long>) con -> con.bitCount(key.getBytes(), start, end));
    }

    /**
     * bitCountByBitIndex 统计值指定范围（范围为位范围）对应位为1的数量
     * 该方法属于扩展方法，由于redis自身未实现位索引查找，所以实现该方法方便按位查找
     *
     * @param key   redis key
     * @param start 开始位位置（包含）
     * @param end   结束位位置（包含）
     * @return
     */
    public Long bitCountByBitIndex(String key, long start, long end) {
        Long c = 0L;
        int k = 8;
        long s = start / k;
        long e = end / k;
        String value = redisTemplate.opsForValue().get(key, s, e);
        int st = (int) (start % k);
        int et = (int) (end % k) + 1;
        for (int i = 0; i < value.length(); i++) {
            int v = value.charAt(i);
            int j = 0;
            if (i == 0) {
                j = st;
            }
            if (i == value.length() - 1) {
                k = et;
            }
            for (; j < k; j++) {
                c += v >> (7 - j) & 1;
            }
        }
        return c;
    }

    /**
     * bitPos 统计值指定范围（范围为字节范围）内第一个0或1
     * 该方法属于扩展方法，由于redisTemplate未实现该方法，所以以该方法代替，当然，也可以使用Lua脚本进行实现
     *
     * @param key   redis key
     * @param value 0（false）或1（true）
     * @param start 开始字节位置（包含）
     * @param end   结束字节位置（包含）
     * @return
     */
    public long bitPos(String key, boolean value, long start, long end) {
        String v = redisTemplate.opsForValue().get(key, start, end);
        for (int i = 0; i < v.length(); i++) {
            int vc = v.charAt(i);
            if ((vc & 255) == 0) {
                if (value) {
                    continue;
                } else {
                    return i * 8;
                }
            }
            for (int j = 0; j < 8; j++) {
                if ((vc & (1 << (7 - j))) == 0) {
                    if (value) {
                        continue;
                    } else {
                        return i * 8 + j;
                    }
                } else {
                    if (value) {
                        return i * 8 + j;
                    } else {
                        continue;
                    }
                }
            }
        }
        return -1;
    }


    // GEO  地址位置
    // Starting with Redis version 6.2.0: Added the CH, NX and XX options.

    /**
     * 添加地理坐标
     *
     * @param key
     * @param point
     * @param member
     * @return
     */
    public Long GeoAdd(String key, Point point, Object member) {
        return redisTemplate.opsForGeo().add(key, point, member);
    }

    public Long GeoRemove(String key, Object... member) {
        return redisTemplate.opsForGeo().remove(key, member);
    }

    /**
     * 返回坐标
     *
     * @param key
     * @param members
     * @return
     */
    public List<Point> GeoPositions(String key, Object... members) {
        return redisTemplate.opsForGeo().position(key, members);
    }

    /**
     * 返回两地的距离，单位 m
     *
     * @param key
     * @param member1
     * @param member2
     * @return
     */
    public Double GeoDistance(String key, Object member1, Object member2) {
        return redisTemplate.opsForGeo().distance(key, member1, member2).getValue();
    }


    /**
     * 返回以 xx 为中心，半径为  radius,单位为 km 的结果
     *
     * @param key
     * @param center 中心地理坐标
     * @param radius 半径，单位 KM
     * @return
     */

    public GeoResults<RedisGeoCommands.GeoLocation<Object>> GeoRadiusResult(String key, Point center, double radius) {
        return redisTemplate.opsForGeo().radius(key, new Circle(center, new Distance(radius, Metrics.KILOMETERS)));
    }

    public GeoResults<RedisGeoCommands.GeoLocation<Object>> GeoRadiusResult(String key, Point center, double radius, boolean km) {
        if (km)
            return redisTemplate.opsForGeo().radius(key, new Circle(center, new Distance(radius, Metrics.KILOMETERS)));
        return redisTemplate.opsForGeo().radius(key, new Circle(center, new Distance(radius, Metrics.MILES)));
    }

    public GeoResults<RedisGeoCommands.GeoLocation<Object>> GeoSearch(String key, Circle circle) {
        return redisTemplate.opsForGeo().search(key, GeoReference.fromCircle(circle), GeoShape.byRadius(circle.getRadius()), RedisGeoCommands.GeoSearchCommandArgs.newGeoSearchArgs());
    }

    public GeoResults<RedisGeoCommands.GeoLocation<Object>> GeoSearch(String key, GeoReference<Object> reference, Distance radius) {
        return redisTemplate.opsForGeo().search(key, reference, radius);
    }

    public GeoResults<RedisGeoCommands.GeoLocation<Object>> GeoSearch(String key, GeoReference<Object> reference, BoundingBox boundingBox) {
        return redisTemplate.opsForGeo().search(key, reference, boundingBox);
    }


}

