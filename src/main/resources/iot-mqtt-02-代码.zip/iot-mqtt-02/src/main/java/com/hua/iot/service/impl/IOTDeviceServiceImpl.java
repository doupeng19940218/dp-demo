package com.hua.iot.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.hua.iot.domain.IOTDevice;
import com.hua.iot.domain.IOTSensor;
import com.hua.iot.entity.IOTDeviceDetail;
import com.hua.iot.mapper.IOTDeviceMapper;
import com.hua.iot.mapper.IOTSensorMapper;
import com.hua.iot.service.IOTDeviceService;
import com.hua.iot.utils.RedisUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/**
 * @author Spring
 * @description 针对表【tb_device】的数据库操作Service实现
 * @createDate 2022-11-08 10:09:31
 */
@Service
public class IOTDeviceServiceImpl extends ServiceImpl<IOTDeviceMapper, IOTDevice>
        implements IOTDeviceService {
    @Autowired
    private RedisUtils redisUtils;
    @Autowired
    private IOTSensorMapper sensorMapper;


    @Override
    public IOTDeviceDetail getDeviceDetailByDeviceId(Integer deviceId) {
        IOTDeviceDetail deviceDetail = new IOTDeviceDetail(deviceId,"");
        //1.  首先想找 Redis缓存，使用 key的正则匹配查询
        String key = "iot" + ":deviceId:" + deviceId;
        Set<String> keys = redisUtils.keys(key + "*");
        if (keys != null && keys.size() > 0) {
            List<IOTSensor> sensorList = new ArrayList<>();
            for (String k : keys) {
                Object v = redisUtils.lIndex(k, 0);
                IOTSensor sensor = new IOTSensor(deviceId, k.substring(k.lastIndexOf(":") + 1),  v);
                sensorList.add(sensor);
            }
            deviceDetail.setSensorList(sensorList);
            System.out.println(sensorList);
            System.out.println(deviceDetail);
            return deviceDetail;
        } else {
            //2.  缓存Redis 没有命中，则去数据库中查找
            IOTDevice iotDevice = query().eq("device_id", deviceId).one();
            List<IOTSensor> iotSensors = sensorMapper.getDistinctSensorByDeviceID(deviceId);
            deviceDetail.setIotDevice(iotDevice);
            deviceDetail.setSensorList(iotSensors);
            return deviceDetail;
        }
    }
}




