package com.hua.iot.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.hua.iot.domain.IOTDevice;
import com.hua.iot.entity.IOTDeviceDetail;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author Spring
 * @description 针对表【tb_device】的数据库操作Mapper
 * @createDate 2022-11-08 10:09:31
 * @Entity com.hua.iot.domain.IOTDevice
 */
@Mapper
public interface IOTDeviceMapper extends BaseMapper<IOTDevice> {

}




