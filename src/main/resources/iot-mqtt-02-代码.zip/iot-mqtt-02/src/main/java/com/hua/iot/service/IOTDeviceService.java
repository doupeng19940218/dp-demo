package com.hua.iot.service;

import com.hua.iot.domain.IOTDevice;
import com.baomidou.mybatisplus.extension.service.IService;
import com.hua.iot.entity.IOTDeviceDetail;

/**
* @author Spring
* @description 针对表【tb_device】的数据库操作Service
* @createDate 2022-11-08 10:09:31
*/
public interface IOTDeviceService extends IService<IOTDevice> {
    /**
     * 获取设备下的传感器信息
     * @param deviceId 设备惟一ID
     * @return 设备详情，包含传感器集合，但是传感器数据只保留最新的一条
     */
    IOTDeviceDetail getDeviceDetailByDeviceId(Integer deviceId);
}
