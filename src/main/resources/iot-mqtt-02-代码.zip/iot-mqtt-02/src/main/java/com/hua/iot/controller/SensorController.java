package com.hua.iot.controller;

import com.baomidou.mybatisplus.core.metadata.IPage;
import com.hua.iot.common.api.CommonResult;
import com.hua.iot.domain.IOTSensor;
import com.hua.iot.service.IOTSensorService;
import com.hua.iot.utils.RedisUtils;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Create By Spring-2022/11/8
 */
@Slf4j
@Controller
@RequestMapping(value = "/sensor")
@Api(value = "SensorController", tags = {"IOT 传感器控制类"})
public class SensorController {
    @Autowired
    private IOTSensorService sensorService;

    @ApiOperation("分页带条件查询指定设备下,所有传感器的历史数据")
    @RequestMapping(value = "/history/values/all/{deviceId}", method = RequestMethod.GET)
    @ResponseBody
    public CommonResult<Object> getSensorInfoByDeviceIdWithOpr(@PathVariable("deviceId") @ApiParam("传感器所属设备ID") Integer deviceId,
                                                   @RequestParam(value = "pageNo", required = false, defaultValue = "1") Integer pageNo,
                                                   @RequestParam(value = "pageSize", required = false, defaultValue = "5") Integer pageSize) {
        IPage<IOTSensor> sensorPage = sensorService.getSensorDataByDeviceIdByOpr(deviceId, pageNo, pageSize);
        return CommonResult.success(sensorPage);
    }

    @ApiOperation("简单的分页带条件查询指定设备下,所有传感器的历史数据")
    @RequestMapping(value = "/history/values/all/simple/{deviceId}", method = RequestMethod.GET)
    @ResponseBody
    public CommonResult<Object> getSensorInfoByDeviceIdSimpleWithOpr(@PathVariable("deviceId") @ApiParam("传感器所属设备ID") Integer deviceId,
                                                               @RequestParam(value = "pageNo", required = false, defaultValue = "1") Integer pageNo,
                                                               @RequestParam(value = "pageSize", required = false, defaultValue = "5") Integer pageSize) {
        Map<String,Object> values = sensorService.getSensorDataByDeviceIdSimpleByOpr(deviceId, pageNo, pageSize);
        return CommonResult.success(values);
    }



    @ApiOperation("分页带条件查询指定设备下,某传感器的历史数据")
    @RequestMapping(value = "/history/values/all/{deviceId}/{sensorTag}", method = RequestMethod.GET)
    @ResponseBody
    public CommonResult<Object> getSensorInfoByDeviceIdAndSensorTagWithOpr(@PathVariable("deviceId") @ApiParam("传感器所属设备ID") Integer deviceId,
                                                   @PathVariable("sensorTag") @ApiParam("传感器标识") String sensorTag,
                                                   @RequestParam(value = "pageNo", required = false, defaultValue = "1") Integer pageNo,
                                                   @RequestParam(value = "pageSize", required = false, defaultValue = "5") Integer pageSize) {
        IPage<IOTSensor> sensorPage = sensorService.getSensorDataByDeviceIdAndSensorTagByOpr(deviceId, sensorTag, pageNo, pageSize);
        return CommonResult.success(sensorPage);
    }

    @ApiOperation("简单的分页带条件查询指定设备下,某传感器的历史数据")
    @RequestMapping(value = "/history/values/all/simple/{deviceId}/{sensorTag}", method = RequestMethod.GET)
    @ResponseBody
    public CommonResult<Object> getSensorInfoByDeviceIdAndSensorTagSimpleWithOpr(@PathVariable("deviceId") @ApiParam("传感器所属设备ID") Integer deviceId,
                                                                           @PathVariable("sensorTag") @ApiParam("传感器标识") String sensorTag,
                                                                           @RequestParam(value = "pageNo", required = false, defaultValue = "1") Integer pageNo,
                                                                           @RequestParam(value = "pageSize", required = false, defaultValue = "5") Integer pageSize) {
        List<Object> values = sensorService.getSensorDataByDeviceIdAndSensorTagSimpleByOpr(deviceId, sensorTag, pageNo, pageSize);
        Map<String,Object> map = new HashMap<>();
        map.put("deviceId",deviceId);
        map.put("sensorTag",sensorTag);
        map.put("datalist",values);
        return CommonResult.success(map);
    }


    @ApiOperation("分页带时间范围内指定设备下,某传感器的历史传感器数据")
    @RequestMapping(value = "/history/values/range/{deviceId}/{sensorTag}", method = RequestMethod.GET)
    @ResponseBody
    public CommonResult<Object> getSensorInfoByDay(@PathVariable("deviceId") @ApiParam("传感器所属设备ID") Integer deviceId,
                                                   @PathVariable("sensorTag") @ApiParam("传感器标识") String sensorTag,
                                                   @RequestParam("startDate") @ApiParam("起始年月日") Date startDate,
                                                   @RequestParam("endDate") @ApiParam("结束年月日") Date endData) {
        List<IOTSensor> sensorList = sensorService.getSensorDataByDeviceIdAndSensorTagByDay(deviceId, sensorTag, startDate, endData);
        Map<String, Object> map = new HashMap<>();
        map.put("sensorTag", sensorTag);
        map.put("startDate", startDate);
        map.put("endDate", endData);
        map.put("datalist", sensorList);
        return CommonResult.success(map);
    }


    @ApiOperation("简单获取指定设备下,所有传感器的最新数据")
    @RequestMapping(value = "/value/latest/simple/{deviceId}}", method = RequestMethod.GET)
    @ResponseBody
    public CommonResult<Object> getLatestSensorValSimple(@PathVariable("deviceId") @ApiParam("传感器所属设备ID") Integer deviceId) {

        Map<String,Object> map = sensorService.getLatestSensorValSimple(deviceId);

        return CommonResult.success(map);
    }

    @ApiOperation("获取指定设备下,某传感器的最新传感器数据")
    @RequestMapping(value = "/value/latest/{deviceId}/{sensorTag}", method = RequestMethod.GET)
    @ResponseBody
    public CommonResult<Object> getLatestSensorVal(@PathVariable("deviceId") @ApiParam("传感器所属设备ID") Integer deviceId,
                                                   @PathVariable("sensorTag") @ApiParam("传感器标识") String sensorTag) {

        IOTSensor sensor = sensorService.getLatestSensorVal(deviceId, sensorTag);

        return CommonResult.success(sensor);
    }
}
