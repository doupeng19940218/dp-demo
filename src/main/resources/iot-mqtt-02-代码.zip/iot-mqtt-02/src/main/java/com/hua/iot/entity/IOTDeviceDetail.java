package com.hua.iot.entity;

import com.hua.iot.domain.IOTDevice;
import com.hua.iot.domain.IOTSensor;

import java.io.Serializable;
import java.util.List;

/**
 * Create By Spring-2022/11/8
 */
public class IOTDeviceDetail extends IOTDevice {

    private List<IOTSensor> sensorList;
    private IOTDevice iotDevice;

    public IOTDeviceDetail() {
    }

    public IOTDeviceDetail(Integer deviceId) {
        super(deviceId);
    }

    public IOTDeviceDetail(Integer deviceId, String deviceName) {
        super(deviceId, deviceName);
    }

    public IOTDevice getIotDevice() {
        return iotDevice;
    }

    public void setIotDevice(IOTDevice iotDevice) {
        this.iotDevice = iotDevice;
    }

    public List<IOTSensor> getSensorList() {
        return sensorList;
    }

    public void setSensorList(List<IOTSensor> sensorList) {
        this.sensorList = sensorList;
    }

    @Override
    public Integer getDeviceId() {
        if (iotDevice != null)
            return iotDevice.getDeviceId();
        return super.getDeviceId();
    }

    @Override
    public void setDeviceId(Integer deviceId) {
        if (iotDevice != null)
            iotDevice.setDeviceId(deviceId);
        else
            super.setDeviceId(deviceId);
    }

    @Override
    public String getDeviceName() {
        if (iotDevice != null)
            return iotDevice.getDeviceName();
        return super.getDeviceName();
    }

    @Override
    public void setDeviceName(String deviceName) {
        if (iotDevice != null)
            iotDevice.setDeviceName(deviceName);
        else
            super.setDeviceName(deviceName);
    }
}
