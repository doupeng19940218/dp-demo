package com.hua.iot.service.impl;

import com.alibaba.druid.util.StringUtils;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.metadata.IPage;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.hua.iot.domain.IOTSensor;
import com.hua.iot.mapper.IOTSensorMapper;
import com.hua.iot.service.IOTSensorService;
import com.hua.iot.utils.RedisUtils;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * @author Spring
 * @description 针对表【tb_sensor】的数据库操作Service实现
 * @createDate 2022-11-08 10:14:23
 */
@Slf4j
@Service
public class IOTSensorServiceImpl extends ServiceImpl<IOTSensorMapper, IOTSensor> implements IOTSensorService {

    @Autowired
    private RedisUtils redisUtils;

    @Override
    public IPage<IOTSensor> getSensorDataByDeviceIdByOpr(Integer deviceId, Integer pageNo, Integer pageSize) {
        return getSensorDataByDeviceIdAndSensorTagByOpr(deviceId, null, pageNo, pageSize);
    }

    @Override
    public IPage<IOTSensor> getSensorDataByDeviceIdAndSensorTagByOpr(Integer deviceId, String sensorTag, Integer pageNo, Integer pageSize) {
        Page<IOTSensor> pn = new Page<>(pageNo, pageSize);
        QueryWrapper<IOTSensor> query = new QueryWrapper<>();
        query.eq(true, "device_id", deviceId);
        if (sensorTag != null && !StringUtils.isEmpty(sensorTag))
            query.eq(true, "sensor_tag", sensorTag);
        return baseMapper.selectPage(pn, query);
    }

    @Override
    public IOTSensor getLatestSensorVal(Integer deviceId, String sensorTag) {

        String key = buildKeyWithDeviceIdAndSensorTag(deviceId, sensorTag);
        Object val = redisUtils.lIndex(key, 0); // 从Redis 列表中，拿第一个，因为是LPush
        if (val != null) {  // redis缓存中有
            return new IOTSensor(deviceId, sensorTag, val);
        } else {
            QueryWrapper<IOTSensor> query = new QueryWrapper<>();
            query.eq(true, "sensor_tag", sensorTag);
            query.eq(true, "device_id", deviceId);
            query.orderByDesc("record_time");
            query.last("limit 1"); // 限制只有一条
            return getOne(query);
        }
    }

    @Override
    public List<IOTSensor> getSensorDataByDeviceIdAndSensorTagByDay(Integer deviceId, String sensorTag, Date startDate, Date endData) {
        QueryWrapper<IOTSensor> query = new QueryWrapper<>();
        query.eq(true, "sensor_tag", sensorTag);
        query.eq(true, "device_id", deviceId);
        query.between("record_time", startDate, endData);
//        query.orderByDesc("record_time");
        return list(query);
    }

    @Override
    public Map<String, Object> getSensorDataByDeviceIdSimpleByOpr(Integer deviceId, Integer pageNo, Integer pageSize) {
        // 简单获取，直接向Redis 缓存拿，不保证所有同步
        String keyPattern = buildKeyWithDeviceIdAndSensorTag(deviceId, "") + "*";
        Set<String> keys = redisUtils.keys(keyPattern);

        long dataStartIndex = (long) (pageNo - 1) * pageSize;  // 数据的起始位置
        long dataEndIndex = (long) pageNo * pageSize; // 数据的结束位置
        long keyStartIndex = 0;
        HashMap<String, Object> resultMap = new HashMap<>();
        for (String key : keys) {
            long keyLen = redisUtils.lLen(key);
            log.warn("Simple get deviceData {}, keyStartIndex={},KeyLen={}, dI={},dE={}",
                    key, keyStartIndex, keyLen, dataStartIndex, dataEndIndex);
            if ((keyStartIndex + keyLen) < dataStartIndex) {
                keyStartIndex += keyLen;
                continue;
            }
            if (keyStartIndex + keyLen < dataEndIndex) {
                List<Object> values = redisUtils.lGet(key, dataStartIndex - keyStartIndex, keyLen);
                resultMap.put(key.substring(key.lastIndexOf(":") + 1), values);
                keyStartIndex += keyLen;
            } else {
                List<Object> values = redisUtils.lGet(key, 0, dataEndIndex - keyStartIndex-1);
                resultMap.put(key.substring(key.lastIndexOf(":") + 1), values);
                keyStartIndex += keyLen;
            }

            if (dataEndIndex <= keyStartIndex) {
                return resultMap;
            }
        }
        return resultMap;
    }

    @Override
    public List<Object> getSensorDataByDeviceIdAndSensorTagSimpleByOpr(Integer deviceId, String sensorTag, Integer pageNo, Integer pageSize) {
        // 简单获取，直接向Redis 缓存拿，不保证所有同步
        String key = buildKeyWithDeviceIdAndSensorTag(deviceId, sensorTag);
        return redisUtils.lGet(key, (long) (pageNo - 1) * pageSize, (long) pageSize * pageNo);
    }

    @Override
    public Map<String, Object> getLatestSensorValSimple(Integer deviceId) {
        String keyPattern = buildKeyWithDeviceIdAndSensorTag(deviceId, "")+"*";
        Set<String> keys = redisUtils.keys(keyPattern);
        HashMap<String, Object> resultMap = new HashMap<>();
        for (String key : keys) {
            resultMap.put(key.substring(key.lastIndexOf(":")+1),redisUtils.lIndex(key,0));
        }
        return resultMap;
    }


    private String buildKeyWithDeviceIdAndSensorTag(Integer deviceId, String sensorTag) {
        return "iot:deviceId:" + deviceId + ":sensorTag:" + sensorTag;
    }
}




