package com.hua.iot.controller;

import com.hua.iot.common.api.CommonResult;
import com.hua.iot.domain.IOTDevice;
import com.hua.iot.entity.IOTDeviceDetail;
import com.hua.iot.service.IOTDeviceService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

/**
 * Create By Spring-2022/11/8
 */
@Controller
@RequestMapping(value = "/device")
@Api(value = "DeviceController", tags = {"IOT 设备控制类"})
public class DeviceController {
    @Autowired
    private IOTDeviceService deviceService;

    @ApiOperation("获取指定设备的详细信息")
    @RequestMapping(value = "/get", method = RequestMethod.GET)
    @ResponseBody
    public CommonResult<IOTDeviceDetail> getDeviceInfoById(@RequestParam("deviceId") @ApiParam("传感器所属设备ID") Integer deviceId) {

        IOTDeviceDetail deviceDetail = deviceService.getDeviceDetailByDeviceId(deviceId);
        return CommonResult.success(deviceDetail);
    }


    @ApiOperation("添加设备信息")
    @RequestMapping(value = "/add",method = RequestMethod.POST)
    @ResponseBody
    public CommonResult<IOTDevice> addDevice(@RequestBody IOTDevice device){
        boolean bOk = deviceService.save(device);
        if(bOk){
            return CommonResult.success(device);
        } else {
            return CommonResult.failed("添加设备失败");
        }
    }

    @ApiOperation("删除设备信息")
    @RequestMapping(value = "/delete",method = RequestMethod.DELETE)
    @ResponseBody
    public CommonResult<IOTDevice> deleteDeviceById(@RequestBody IOTDevice device){
        boolean bOk = deviceService.removeById(device.getDeviceId());
        if(bOk){
            return CommonResult.success(device);
        } else {
            return CommonResult.failed("删除设备失败");
        }
    }

    @ApiOperation("根据设备ID 更新设备信息")
    @RequestMapping(value = "/update",method = RequestMethod.PUT)
    @ResponseBody
    public CommonResult<IOTDevice> updateDeviceById(@RequestParam("deviceId") Integer deviceId,
                                                @RequestParam("deviceName") String deviceName){
        IOTDevice device = new IOTDevice(deviceId,deviceName);
        boolean bOk = deviceService.updateById(device);
        if(bOk){
            return CommonResult.success(device);
        } else {
            return CommonResult.failed("更新设备失败");
        }
    }
}
