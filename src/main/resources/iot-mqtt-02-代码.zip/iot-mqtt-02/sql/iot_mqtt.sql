/*
 Navicat Premium Data Transfer

 Source Server         : iot
 Source Server Type    : MySQL
 Source Server Version : 80018
 Source Host           : localhost:3306
 Source Schema         : iot_mqtt

 Target Server Type    : MySQL
 Target Server Version : 80018
 File Encoding         : 65001

 Date: 08/11/2022 12:53:36
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for tb_device
-- ----------------------------
DROP TABLE IF EXISTS `tb_device`;
CREATE TABLE `tb_device`  (
                              `device_id` int(32) NOT NULL COMMENT '设备ID 惟一',
                              `device_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
                              PRIMARY KEY (`device_id`) USING BTREE,
                              UNIQUE INDEX `deviceId`(`device_id`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of tb_device
-- ----------------------------
INSERT INTO `tb_device` VALUES (10000001, 'Test1');
INSERT INTO `tb_device` VALUES (10000002, 'Test2');
INSERT INTO `tb_device` VALUES (10000003, 'Test3');
INSERT INTO `tb_device` VALUES (10000004, 'Test4');
INSERT INTO `tb_device` VALUES (10000005, 'Test5');

-- ----------------------------
-- Table structure for tb_sensor
-- ----------------------------
DROP TABLE IF EXISTS `tb_sensor`;
CREATE TABLE `tb_sensor`  (
                              `device_id` int(32) NULL DEFAULT NULL,
                              `sensor_tag` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
                              `sensor_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
                              `sensor_val` float(32, 2) NULL DEFAULT NULL,
                              `record_time` datetime(0) NULL DEFAULT NULL,
                              INDEX `deviceId`(`device_id`) USING BTREE,
                              CONSTRAINT `deviceId` FOREIGN KEY (`device_id`) REFERENCES `tb_device` (`device_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE = InnoDB CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of tb_sensor
-- ----------------------------
INSERT INTO `tb_sensor` VALUES (10000001, 'co', '一氧化碳', 20.10, '2022-11-07 20:23:48');
INSERT INTO `tb_sensor` VALUES (10000001, 'co2', '二氧化碳', 22.10, '2022-11-07 20:24:16');
INSERT INTO `tb_sensor` VALUES (10000001, 'co2', '二氧化碳', 19.20, '2022-11-07 20:24:42');
INSERT INTO `tb_sensor` VALUES (10000002, 'so2', '二氧化硫', 2.30, '2022-11-07 20:25:42');
INSERT INTO `tb_sensor` VALUES (10000002, 'co', '一氧化碳', 18.20, '2022-11-07 20:26:15');
INSERT INTO `tb_sensor` VALUES (10000003, 'so2', '二氧化硫', 3.20, '2022-11-07 20:26:38');
INSERT INTO `tb_sensor` VALUES (10000004, 'temp', '温度', 30.20, '2022-11-07 20:27:07');
INSERT INTO `tb_sensor` VALUES (10000004, 'humity', '湿度', 40.00, '2022-11-07 20:28:15');
INSERT INTO `tb_sensor` VALUES (10000005, 'tmep', '温度', 31.20, '2022-11-07 20:28:41');
INSERT INTO `tb_sensor` VALUES (10000005, 'humity', '湿度', 45.00, '2022-11-07 20:29:02');

SET FOREIGN_KEY_CHECKS = 1;


-- JOIN 查询举例
-- SELECT
--   device.device_id,
--   device.device_name,
--   sensor.sensor_tag,
--   sensor.sensor_val,
--   sensor.sensor_name,
--   sensor.record_time
-- FROM
--   tb_sensor AS sensor
--   RIGHT JOIN tb_device AS device ON sensor.device_id = device.device_id
-- WHERE
--   device.device_id = 10000002;